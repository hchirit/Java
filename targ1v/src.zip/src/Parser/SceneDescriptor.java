package Parser;

/**
 * Created by HC on 06/06/2017.
 */
public class SceneDescriptor {
    void getTriangles(){}
}
