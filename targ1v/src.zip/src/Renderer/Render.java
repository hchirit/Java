package Renderer;

import java.awt.Color;
import java.util.*;
import Elements.LightSource;
import Geometries.FlatGeometry;
import Geometries.Geometry;
import Primitives.Point3D;
import Primitives.Ray;
import Primitives.Vector;
import Scene.Scene;
import java.util.Map.Entry;
/**
 * Created by HC on 04/06/2017.
 */
public class Render {

    /** A Render is an engine that prepare a scene and its components.
     * It also write the scene into a file with the help of ImageWriter class.
     * */

    private Scene _scene;
    private ImageWriter _imageWriter;
    private final int RECURSION_LEVEL = 3;

    // ***************** Constructors ********************** //



    public Render(ImageWriter imageWriter, Scene scene) {
        _scene = new Scene(scene);
        _imageWriter = new ImageWriter(imageWriter);
    }

    // ***************** Operations ******************** //


    public void renderImage(){
        // Scan the screen rows.
        for(int i = 0; i<_imageWriter.getHeight(); i++) {
            // scan all the columns for one row.
            for(int j = 0; j<_imageWriter.getWidth(); j++){

                Ray ray = _scene.getCamera().constructRayThroughPixel(_imageWriter.getNx(),
                        _imageWriter.getNy(), j, i, _scene.getScreenDistance(),
                        _imageWriter.getWidth(), _imageWriter.getHeight());

                Entry<Geometry, Point3D> intersectionPoint = findClosesntIntersection(ray);

                // When there are no objects in the scene.
                if(intersectionPoint == null){
                    _imageWriter.writePixel(j,i,_scene.getBackground());
                } else{
                    _imageWriter.writePixel(j,i,calcColor(intersectionPoint.getKey(),intersectionPoint.getValue(),ray));
                }
            }
        }
    }



    private Entry<Geometry, Point3D> findClosesntIntersection(Ray ray){

        Map<Geometry,List<Point3D>> intersectionPoints = getSceneRayIntersections(ray);

        if(intersectionPoints.size() == 0)
            return null;

        Map<Geometry,Point3D> closestPoint = getClosestPoint(intersectionPoints);
        Entry<Geometry,Point3D> entry = closestPoint.entrySet().iterator().next();
        return entry;
    }



    public void printGrid(int interval){

        int height = _imageWriter.getHeight();
        int width = _imageWriter.getWidth();

        for (int i = 0; i < height; i++){
            for (int j = 0; j < width; j++){

                if (i % interval == 0 || j % interval == 0)
                    _imageWriter.writePixel(j, i, 255, 255, 255);

            }
        }
    }



    private Color calcColor(Geometry geometry, Point3D point, Ray ray){
        Color ambient = _scene.getAmbientLight().getIntensity();
        Color emission = geometry.getEmmission();

        Color light = addColors(ambient,emission);
        Color light1 = new Color(0);
        Iterator<LightSource> lights = _scene.getLightsIterator();
        while(lights.hasNext())
        {
            LightSource lightsource = lights.next();
            Color lightIntensity = lightsource.getIntensity(point);

            Color diffuseLight = calcDiffusiveComp(geometry.getMaterial().getKd(), geometry.getNormal(point), lightsource.getL(point), lightIntensity);

            Color lightSpecular = calcSpecularComp(geometry.getMaterial().getKs(), new Vector(point, _scene.getCamera().getP0()), geometry.getNormal(point), lightsource.getL(point), geometry.getShininess(), lightIntensity);

            light1 = addColors(diffuseLight,lightSpecular);
        }
        Color IO = addColors(light, light1);
        return IO;
    }

    private Color calcSpecularComp(double ks, Vector vector, Vector N, Vector D, double shininess, Color lightIntensity) {
        vector.normalize();
        N.normalize();
        D.normalize();
        double k = 0;

        double Dtemp = D.dotProduct(N);
        N.scale(-2*Dtemp);
        D.add(N);

        Vector R = new Vector(D);

        if(vector.dotProduct(R)>0){
            k = ks*Math.pow(vector.dotProduct(R),shininess);
        }

        Color IO = new Color((int)(lightIntensity.getRed() * k),
                (int)(lightIntensity.getGreen() * k),
                (int)(lightIntensity.getBlue()   * k));

        return IO;

    }

    private Color calcDiffusiveComp(double kd, Vector normal, Vector l, Color lightIntensity) {
        normal.normalize();
        l.normalize();
        double dot = normal.dotProduct(l);

        double temp = Math.abs(kd*dot);

        Color IO = new Color((int)(lightIntensity.getRed() * temp),
                (int)(lightIntensity.getGreen() * temp),
                (int)(lightIntensity.getBlue() * temp));

        return IO;
    }



    private Map<Geometry, Point3D> getClosestPoint(Map<Geometry, List<Point3D>> intersectionPoints) {
        Map<Geometry, Point3D> geometriesClosestPoint = new HashMap<Geometry,Point3D>();
        double max = 999999999;
        Point3D p0=_scene.getCamera().getP0();
        double distance;

        for(Entry<Geometry,List<Point3D>> intersectionsIt : intersectionPoints.entrySet()){
            for(Point3D p : intersectionsIt.getValue())
            {
                distance=p0.distance(p);
                while(max>distance)
                {
                    geometriesClosestPoint.clear();
                    geometriesClosestPoint.put(intersectionsIt.getKey(),p);
                    max=distance;
                }
            }
        }

        return  geometriesClosestPoint;
    }



    private Map<Geometry, List<Point3D>> getSceneRayIntersections(Ray ray) {
        Iterator<Geometry> geometries = _scene.getGeometriesIterator();
        Map<Geometry, List<Point3D>> geometryIntersections = new HashMap<Geometry,List<Point3D>>();

        while(geometries.hasNext()) {
            Geometry geometry = geometries.next();
            List<Point3D> geometryIntersectionPoints = geometry.FindIntersections(ray);
            if (!geometryIntersectionPoints.isEmpty())
                geometryIntersections.put(geometry, geometryIntersectionPoints);
        }
        return geometryIntersections;
    }



    private Color addColors(Color a, Color b){
        int R = a.getRed() + b.getRed();
        if(R>255)
            R = 255;
        int G = a.getGreen() + b.getGreen();
        if(G>255)
            G = 255;
        int B = a.getBlue() + b.getBlue();
        if(B>255)
            B = 255;

        return new Color(R,G,B);
    }

    public void writeToImage(){_imageWriter.writeToimage();}
    //private Color calcColor(Geometry geometry, Point3D point, Ray inRay, int level){} // Recursive
    //private Ray constructRefractedRay(Geometry geometry, Point3D point, Ray inRay){}
    //private Ray constructReflectedRay(Vector normal, Point3D point, Ray inRay){}
    //private boolean occluded(LightSource light, Point3D point, Geometry geometry){}


}
