package Geometries;

/**
 * Created by HC on 01/05/2017.
 */
public interface FlatGeometry {
}
